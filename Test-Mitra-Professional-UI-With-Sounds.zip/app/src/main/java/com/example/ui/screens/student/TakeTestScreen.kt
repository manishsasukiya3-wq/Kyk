package com.example.ui.screens.student

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import com.example.ui.components.QuestionImageDisplay
import com.example.ui.components.QuestionPassageDisplay
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBlueLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.util.AppSoundManager
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TakeTestScreen(
    testId: Long,
    testName: String,
    durationMinutes: Int,
    user: User,
    repository: TestMitraRepository,
    onTestFinished: (testId: Long, testName: String, totalQuestions: Int, correctCount: Int, score: Double, answersMapJson: String) -> Unit,
    onCancelTest: () -> Unit
) {
    var questions by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var isLoading by remember { mutableStateOf(true) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSubmitDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }
    var submitErrorMessage by remember { mutableStateOf<String?>(null) }

    val selectedAnswers = remember { mutableStateMapOf<Long, String>() }
    val initialSeconds = remember { (if (durationMinutes > 0) durationMinutes else 15) * 60 }
    var remainingSeconds by remember { mutableIntStateOf(initialSeconds) }
    val scope = rememberCoroutineScope()

    fun loadQuestions() {
        isLoading = true
        errorMessage = null
        scope.launch {
            val testsRes = repository.getTests()
            if (testsRes is Resource.Success) {
                val currentTest = testsRes.data.firstOrNull { it.id == testId }
                if (currentTest != null && !currentTest.isTestActive && !user.isTeacherOrAdmin) {
                    isLoading = false
                    errorMessage = "This test has been deactivated by the admin."
                    return@launch
                }
            }

            when (val res = repository.getQuestionsForTest(testId)) {
                is Resource.Success -> {
                    isLoading = false
                    questions = res.data.sortedBy { it.id ?: 0L }
                }
                is Resource.Error -> {
                    isLoading = false
                    errorMessage = res.message
                }
                else -> {}
            }
        }
    }

    LaunchedEffect(testId) {
        loadQuestions()
    }

    fun performSubmit() {
        if (isSubmitting) return
        isSubmitting = true
        submitErrorMessage = null

        scope.launch {
            var correctCount = 0
            val answersMap = mutableMapOf<String, String>()

            questions.forEach { q ->
                val qId = q.id ?: 0L
                val chosen = selectedAnswers[qId] ?: ""
                answersMap[qId.toString()] = chosen
                if (chosen.isNotBlank() && chosen.equals(q.normalizedCorrectOption(), ignoreCase = true)) {
                    correctCount++
                }
            }

            val finalScore = correctCount.toDouble()
            val userId = user.id ?: 0L

            // Call guaranteed reliable submitResult
            val resultSaveRes = repository.submitResult(
                userId = userId,
                testId = testId,
                score = finalScore,
                userMobile = user.mobileNumber
            )

            if (resultSaveRes is Resource.Error) {
                isSubmitting = false
                submitErrorMessage = resultSaveRes.message
                return@launch
            }

            val moshi = Moshi.Builder().build()
            val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
            val adapter = moshi.adapter<Map<String, String>>(type)
            val jsonString = adapter.toJson(answersMap)

            isSubmitting = false
            onTestFinished(
                testId,
                testName,
                questions.size,
                correctCount,
                finalScore,
                jsonString
            )
        }
    }

    // Timer countdown
    LaunchedEffect(isLoading, questions.size) {
        if (!isLoading && questions.isNotEmpty()) {
            while (remainingSeconds > 0) {
                delay(1000L)
                remainingSeconds--
            }
            if (remainingSeconds <= 0 && !isSubmitting) {
                performSubmit()
            }
        }
    }

    BackHandler {
        showExitDialog = true
    }

    val soundContext = LocalContext.current
    val soundMuted = AppSoundManager.isMuted

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = testName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (questions.isNotEmpty()) "Question ${currentIndex + 1} of ${questions.size}" else "Online Test",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { AppSoundManager.playClick(); showExitDialog = true },
                        modifier = Modifier.testTag("exit_test_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Test",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { AppSoundManager.toggle(soundContext) },
                        modifier = Modifier.testTag("sound_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (soundMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = if (soundMuted) "Turn sounds on" else "Mute all app sounds",
                            tint = Color.White
                        )
                    }
                    val minutes = remainingSeconds / 60
                    val seconds = remainingSeconds % 60
                    val isUrgent = remainingSeconds <= 120

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isUrgent) MitraError else MitraGreen,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("timer_display")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.QueryBuilder,
                                contentDescription = "Timer",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d", minutes, seconds),
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MitraNavyPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = MitraBgLight,
        modifier = Modifier
            .fillMaxSize()
            .testTag("take_test_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MitraBgLight)
                .padding(innerPadding)
        ) {
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = MitraNavyPrimary,
                                strokeWidth = 3.5.dp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Loading test questions...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadQuestions() }
                    )
                }
                questions.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "No Questions in this Test",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MitraTextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "No questions have been added to this test yet.",
                                    fontSize = 13.sp,
                                    color = MitraTextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(18.dp))
                                MitraPrimaryButton(
                                    text = "Back to Tests",
                                    onClick = onCancelTest
                                )
                            }
                        }
                    }
                }
                else -> {
                    val currentQuestion = questions[currentIndex]
                    val qId = currentQuestion.id ?: 0L
                    val selectedOpt = selectedAnswers[qId]

                    Column(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Progress bar
                        LinearProgressIndicator(
                            progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = MitraGreen,
                            trackColor = Color(0xFFE2E8F0)
                        )

                        // Question Navigation Palette
                        Surface(
                            color = Color.White,
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                itemsIndexed(questions) { idx, q ->
                                    val itemQId = q.id ?: 0L
                                    val isAnswered = selectedAnswers.containsKey(itemQId) && selectedAnswers[itemQId]?.isNotBlank() == true
                                    val isCurrent = idx == currentIndex

                                    Surface(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .clickable { currentIndex = idx }
                                            .testTag("question_palette_chip_$idx"),
                                        shape = CircleShape,
                                        color = when {
                                            isCurrent -> MitraNavyPrimary
                                            isAnswered -> MitraGreenLight
                                            else -> Color(0xFFF1F5F9)
                                        },
                                        border = if (isAnswered && !isCurrent) BorderStroke(1.5.dp, MitraGreen) else null
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${idx + 1}",
                                                fontSize = 13.sp,
                                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                                color = when {
                                                    isCurrent -> Color.White
                                                    isAnswered -> MitraGreen
                                                    else -> MitraTextSecondary
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Scrollable Question & Options Container
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Optional Reading Comprehension Passage (shown above Question Card if present)
                            if (!currentQuestion.passageText.isNullOrBlank()) {
                                QuestionPassageDisplay(passageText = currentQuestion.passageText)
                            }

                            // Question Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("question_card"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp)
                                        .animateContentSize()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MitraNavyPrimary
                                        ) {
                                            Text(
                                                text = "Question ${currentIndex + 1}",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }

                                        Text(
                                            text = "${selectedAnswers.size} / ${questions.size} Answered",
                                            fontSize = 12.sp,
                                            color = MitraTextMuted,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Optional Question Image (shown ABOVE Question Text if present)
                                    if (!currentQuestion.imageUrl.isNullOrBlank()) {
                                        QuestionImageDisplay(imageUrl = currentQuestion.imageUrl)
                                        Spacer(modifier = Modifier.height(14.dp))
                                    }

                                    // Question text with proper wrap & Gujarati line height
                                    Text(
                                        text = currentQuestion.questionText,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MitraTextPrimary,
                                        lineHeight = 24.sp,
                                        softWrap = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            // 4 MCQ Options (A, B, C, D) with proper wrap
                            OptionCard(
                                letter = "A",
                                text = currentQuestion.optionA,
                                isSelected = selectedOpt == "A",
                                onSelect = { selectedAnswers[qId] = "A" },
                                testTag = "option_a_button"
                            )

                            OptionCard(
                                letter = "B",
                                text = currentQuestion.optionB,
                                isSelected = selectedOpt == "B",
                                onSelect = { selectedAnswers[qId] = "B" },
                                testTag = "option_b_button"
                            )

                            OptionCard(
                                letter = "C",
                                text = currentQuestion.optionC,
                                isSelected = selectedOpt == "C",
                                onSelect = { selectedAnswers[qId] = "C" },
                                testTag = "option_c_button"
                            )

                            OptionCard(
                                letter = "D",
                                text = currentQuestion.optionD,
                                isSelected = selectedOpt == "D",
                                onSelect = { selectedAnswers[qId] = "D" },
                                testTag = "option_d_button"
                            )

                            // Clear Choice Button
                            if (selectedOpt != null) {
                                TextButton(
                                    onClick = { AppSoundManager.playClick(); selectedAnswers.remove(qId) },
                                    modifier = Modifier
                                        .align(Alignment.End)
                                        .testTag("clear_selection_button")
                                ) {
                                    Text(
                                        text = "Clear Selection",
                                        fontSize = 12.sp,
                                        color = MitraOrange,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Bottom Navigation & Submit Bar
                        Surface(
                            color = Color.White,
                            shadowElevation = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    MitraOutlinedButton(
                                        text = "Prev",
                                        onClick = { AppSoundManager.playClick();
                                            if (currentIndex > 0) currentIndex--
                                        },
                                        enabled = currentIndex > 0,
                                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                                        modifier = Modifier.weight(1f),
                                        height = 48.dp,
                                        testTag = "prev_question_button"
                                    )

                                    if (currentIndex < questions.size - 1) {
                                        MitraPrimaryButton(
                                            text = "Next",
                                            onClick = { AppSoundManager.playClick();
                                                if (currentIndex < questions.size - 1) currentIndex++
                                            },
                                            icon = Icons.AutoMirrored.Filled.ArrowForward,
                                            modifier = Modifier.weight(1f),
                                            height = 48.dp,
                                            testTag = "next_question_button"
                                        )
                                    } else {
                                        MitraSuccessButton(
                                            text = "Submit Test",
                                            onClick = { AppSoundManager.playClick(); showSubmitDialog = true },
                                            icon = Icons.Default.Send,
                                            modifier = Modifier.weight(1f),
                                            isLoading = isSubmitting,
                                            testTag = "submit_test_button"
                                        )
                                    }
                                }

                                if (currentIndex < questions.size - 1) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    MitraSuccessButton(
                                        text = "Submit Test (${selectedAnswers.size}/${questions.size})",
                                        onClick = { AppSoundManager.playClick(); showSubmitDialog = true },
                                        icon = Icons.Default.Send,
                                        modifier = Modifier.fillMaxWidth(),
                                        isLoading = isSubmitting,
                                        testTag = "quick_submit_test_button"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // In-flight Submitting Overlay
            if (isSubmitting) {
                Surface(
                    color = Color.Black.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = MitraGreen, strokeWidth = 3.dp)
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Saving result to Supabase...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MitraNavyDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Please wait while your answers are submitted...",
                                    fontSize = 13.sp,
                                    color = MitraTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Submit Confirmation Dialog
    if (showSubmitDialog) {
        val answeredCount = selectedAnswers.size
        val unansweredCount = questions.size - answeredCount

        AlertDialog(
            onDismissRequest = { if (!isSubmitting) showSubmitDialog = false },
            title = {
                Text(
                    text = "Submit Test?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Total Questions: ${questions.size}",
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Answered: $answeredCount",
                        color = MitraGreen,
                        fontWeight = FontWeight.Bold
                    )
                    if (unansweredCount > 0) {
                        Text(
                            text = "Unanswered: $unansweredCount",
                            color = MitraOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Are you sure you want to submit? After submission you will get your instant result.",
                        fontSize = 13.sp,
                        color = MitraTextSecondary
                    )
                }
            },
            confirmButton = {
                MitraSuccessButton(
                    text = "Confirm & Submit",
                    onClick = { AppSoundManager.playClick();
                        showSubmitDialog = false
                        performSubmit()
                    },
                    isLoading = isSubmitting,
                    testTag = "confirm_submit_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { AppSoundManager.playClick(); showSubmitDialog = false },
                    enabled = !isSubmitting,
                    modifier = Modifier.testTag("cancel_submit_button")
                ) {
                    Text("Continue Test", color = MitraTextSecondary)
                }
            }
        )
    }

    // Exit Confirmation Dialog
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = {
                Text("Exit Test?", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("If you leave now, your progress will not be saved.")
            },
            confirmButton = {
                TextButton(
                    onClick = { AppSoundManager.playClick();
                        showExitDialog = false
                        onCancelTest()
                    },
                    modifier = Modifier.testTag("confirm_exit_button")
                ) {
                    Text("Exit", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { AppSoundManager.playClick(); showExitDialog = false },
                    modifier = Modifier.testTag("cancel_exit_button")
                ) {
                    Text("Stay")
                }
            }
        )
    }

    // Submit Failure / Error Dialog with explicit Retry
    if (submitErrorMessage != null) {
        AlertDialog(
            onDismissRequest = { submitErrorMessage = null },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White,
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MitraError,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Submission Failed",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MitraError,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = submitErrorMessage ?: "Could not connect to Supabase.",
                        color = MitraTextPrimary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Please tap 'Retry' below to try saving again.",
                        color = MitraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                MitraSuccessButton(
                    text = "Retry Save",
                    onClick = { AppSoundManager.playClick();
                        submitErrorMessage = null
                        performSubmit()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "retry_submit_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { AppSoundManager.playClick(); submitErrorMessage = null },
                    modifier = Modifier.testTag("dismiss_submit_error_button")
                ) {
                    Text("Cancel", color = MitraTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun OptionCard(
    letter: String,
    text: String,
    isSelected: Boolean,
    onSelect: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MitraBlueLight else Color.White
        ),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) MitraNavyPrimary else MitraBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(34.dp),
                shape = CircleShape,
                color = if (isSelected) MitraNavyPrimary else Color(0xFFF1F5F9)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = letter,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MitraNavyPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Text(
                text = text,
                fontSize = 15.sp,
                color = if (isSelected) MitraNavyDark else MitraTextPrimary,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.weight(1f),
                lineHeight = 22.sp,
                softWrap = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = MitraNavyPrimary,
                    unselectedColor = MitraBorder
                )
            )
        }
    }
}
