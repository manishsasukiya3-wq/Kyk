package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.app.DatePickerDialog
import android.net.Uri
import java.util.Calendar
import com.example.data.local.SessionManager
import com.example.ui.components.QuestionImageDisplay
import com.example.ui.components.QuestionImagePicker
import com.example.ui.components.QuestionPassageDisplay
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.ResultModel
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import com.example.util.AppSoundManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onTakeTest: (testId: Long, testName: String, duration: Int) -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var usersList by remember { mutableStateOf<List<User>>(emptyList()) }
    var adminCompletedResultsMap by remember { mutableStateOf<Map<Long, EnrichedResult>>(emptyMap()) }
    var testQuestionCounts by remember { mutableStateOf<Map<Long, Int>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var testSearchQuery by remember { mutableStateOf("") }

    // Dialog state for viewing/editing
    var viewingQuestionsTest by remember { mutableStateOf<TestItem?>(null) }
    var viewingQuestionsTestIndex by remember { mutableIntStateOf(1) }
    var testQuestionsList by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var isLoadingQuestions by remember { mutableStateOf(false) }
    var questionToDelete by remember { mutableStateOf<QuestionItem?>(null) }
    var testToEdit by remember { mutableStateOf<TestItem?>(null) }
    var questionToEdit by remember { mutableStateOf<QuestionItem?>(null) }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun loadAllData() {
        isLoading = true
        errorMessage = null
        scope.launch {
            val testsRes = repository.getTests()
            val usersRes = repository.getAllUsers()
            val adminResultsRes = repository.getStudentResults(user.id ?: 0L, user.mobileNumber)

            isLoading = false
            when {
                testsRes is Resource.Success -> {
                    testsList = testsRes.data.sortedByDescending { it.id ?: 0L }
                    if (usersRes is Resource.Success) {
                        usersList = usersRes.data
                    }
                    if (adminResultsRes is Resource.Success) {
                        adminCompletedResultsMap = adminResultsRes.data.associateBy { it.testId }
                    }
                }
                testsRes is Resource.Error -> {
                    errorMessage = testsRes.message
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        loadAllData()
    }

    val isSuperAdmin = user.isSuperAdminUser
    val studentCount = usersList.count { !it.isTeacherOrAdmin }
    val adminCount = usersList.count { it.isTeacherOrAdmin }

    // Filter tests by search query (by Name, Date, or Day)
    val filteredTests = remember(testsList, testSearchQuery) {
        if (testSearchQuery.isBlank()) testsList
        else testsList.filter { it.matchesSearch(testSearchQuery) }
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = if (isSuperAdmin) "Super Admin • ${user.name ?: user.mobileNumber}" else "Admin • ${user.name ?: user.mobileNumber}",
                userRole = if (isSuperAdmin) "Super Admin" else "Admin",
                onRefresh = { loadAllData() },
                onLogout = {
                    scope.launch {
                        repository.clearUserDeviceId(user.id ?: 0L)
                        sessionManager.clearSession()
                        onLogout()
                    }
                }
            )
        },
        containerColor = MitraBgLight,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MitraBgLight)
                .padding(innerPadding)
        ) {
            when {
                isLoading && testsList.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Connecting to Supabase...\nLoading data...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadAllData() }
                    )
                }
                else -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Navigation Tabs with ScrollableTabRow to fit all actions cleanly
                        ScrollableTabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.White,
                            contentColor = MitraNavyPrimary,
                            edgePadding = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { AppSoundManager.playClick(); selectedTab = 0 },
                                text = {
                                    Text(
                                        text = "Tests (${testsList.size})",
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_tests")
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { AppSoundManager.playClick(); selectedTab = 1 },
                                text = {
                                    Text(
                                        text = "Results Dashboard",
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_results")
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { AppSoundManager.playClick(); selectedTab = 2 },
                                text = {
                                    Text(
                                        text = "Students ($studentCount)",
                                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_students")
                            )
                            if (isSuperAdmin) {
                                Tab(
                                    selected = selectedTab == 3,
                                    onClick = { AppSoundManager.playClick(); selectedTab = 3 },
                                    text = {
                                        Text(
                                            text = "Admins ($adminCount)",
                                            fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 13.sp
                                        )
                                    },
                                    modifier = Modifier.testTag("admin_tab_admins")
                                )
                            }
                            val createTabIndex = if (isSuperAdmin) 4 else 3
                            Tab(
                                selected = selectedTab == createTabIndex,
                                onClick = { AppSoundManager.playClick(); selectedTab = createTabIndex },
                                text = {
                                    Text(
                                        text = "+ Create / Add",
                                        fontWeight = if (selectedTab == createTabIndex) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_add")
                            )
                        }

                        // Tab 0: Tests Management with Test Search & Take Test
                        if (selectedTab == 0) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp)
                            ) {
                                // Feature 2: Test Search Bar at top of Test Section
                                OutlinedTextField(
                                    value = testSearchQuery,
                                    onValueChange = { testSearchQuery = it },
                                    placeholder = { Text("Search tests by name, date or day...") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Search, contentDescription = "Search", tint = MitraNavyPrimary)
                                    },
                                    trailingIcon = {
                                        if (testSearchQuery.isNotBlank()) {
                                            IconButton(onClick = { AppSoundManager.playClick(); testSearchQuery = "" }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp)
                                        .testTag("admin_test_search_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MitraNavyPrimary,
                                        unfocusedBorderColor = MitraBorder,
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White
                                    )
                                )

                                if (filteredTests.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = if (testSearchQuery.isNotBlank()) "No Tests Match Search" else "No Tests Created Yet",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MitraTextPrimary
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = if (testSearchQuery.isNotBlank()) "No tests found matching \"$testSearchQuery\"." else "Go to 'Create / Add' tab to create your first test.",
                                                fontSize = 13.sp,
                                                color = MitraTextSecondary
                                            )
                                        }
                                    }
                                } else {
                                    LazyColumn(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .testTag("admin_tests_list"),
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        itemsIndexed(filteredTests, key = { _, it -> it.id ?: 0L }) { _, test ->
                                            val testSeqNumber = getTestSequenceNumber(test.id ?: 0L, testsList)
                                            val completedResult = adminCompletedResultsMap[test.id ?: 0L]
                                            val totalQuestions = testQuestionCounts[test.id ?: 0L] ?: 0

                                            AdminTestItemCard(
                                                test = test,
                                                testSequenceNumber = testSeqNumber,
                                                isSuperAdmin = isSuperAdmin,
                                                completedResult = completedResult,
                                                totalQuestionsCount = totalQuestions,
                                                onTakeTest = {
                                                    // Feature 1: Admin & Super Admin can take available tests
                                                    onTakeTest(test.id ?: 0L, "Test $testSeqNumber: ${test.testName}", test.duration)
                                                },
                                                onToggleActive = { newStatus ->
                                                    testsList = testsList.map {
                                                        if (it.id == test.id) it.copy(isActive = newStatus) else it
                                                    }
                                                    scope.launch {
                                                        val res = repository.updateTestStatus(test.id ?: 0L, newStatus)
                                                        if (res is Resource.Success) {
                                                            val statusText = if (newStatus) "Active" else "Deactive"
                                                            snackbarHostState.showSnackbar("Status updated: $statusText")
                                                        } else if (res is Resource.Error) {
                                                            snackbarHostState.showSnackbar(res.message)
                                                            loadAllData()
                                                        }
                                                    }
                                                },
                                                onViewQuestions = {
                                                    viewingQuestionsTest = test
                                                    viewingQuestionsTestIndex = testSeqNumber
                                                    isLoadingQuestions = true
                                                    testQuestionsList = emptyList()
                                                    scope.launch {
                                                        val qRes = repository.getQuestionsForTest(test.id ?: 0L)
                                                        isLoadingQuestions = false
                                                        if (qRes is Resource.Success) {
                                                            val questions = qRes.data.sortedBy { it.id ?: 0L }
                                                            testQuestionsList = questions
                                                            test.id?.let { tId ->
                                                                testQuestionCounts = testQuestionCounts + (tId to questions.size)
                                                            }
                                                        }
                                                    }
                                                },
                                                onEdit = { testToEdit = test },
                                                onDelete = {
                                                    if (!isSuperAdmin) return@AdminTestItemCard
                                                    scope.launch {
                                                        val delRes = repository.deleteTest(test.id ?: 0L, user)
                                                        if (delRes is Resource.Success) {
                                                            snackbarHostState.showSnackbar("Test deleted successfully")
                                                            loadAllData()
                                                        } else if (delRes is Resource.Error) {
                                                            snackbarHostState.showSnackbar(delRes.message)
                                                        }
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        // Tab 1: Feature 3 - Results Dashboard (from TEST MITRA RESULTS, Admin/Super Admin only)
                        else if (selectedTab == 1) {
                            AdminResultsDashboardSection(
                                testsList = testsList,
                                repository = repository
                            )
                        }
                        // Tab 2: Students Management Section
                        else if (selectedTab == 2) {
                            AdminStudentsSection(
                                currentUser = user,
                                usersList = usersList,
                                repository = repository,
                                onStudentAdded = {
                                    loadAllData()
                                    scope.launch { snackbarHostState.showSnackbar("Student added successfully!") }
                                },
                                onStudentUpdated = {
                                    loadAllData()
                                    scope.launch { snackbarHostState.showSnackbar("Student updated successfully!") }
                                },
                                onStudentDeleted = {
                                    loadAllData()
                                    scope.launch { snackbarHostState.showSnackbar("Student removed!") }
                                }
                            )
                        }
                        // Tab 3: Admins Management (Super Admin only) OR Create / Add (Normal Admin)
                        else if (selectedTab == 3) {
                            if (isSuperAdmin) {
                                AdminManagementSection(
                                    currentUser = user,
                                    usersList = usersList,
                                    repository = repository,
                                    onAdminAdded = {
                                        loadAllData()
                                        scope.launch { snackbarHostState.showSnackbar("Admin added successfully!") }
                                    },
                                    onAdminUpdated = {
                                        loadAllData()
                                        scope.launch { snackbarHostState.showSnackbar("Admin updated successfully!") }
                                    },
                                    onAdminDeleted = {
                                        loadAllData()
                                        scope.launch { snackbarHostState.showSnackbar("Admin removed!") }
                                    },
                                    onStatusChanged = {
                                        loadAllData()
                                        scope.launch { snackbarHostState.showSnackbar("Admin status updated!") }
                                    }
                                )
                            } else {
                                AdminCreateContentSection(
                                    testsList = testsList,
                                    repository = repository,
                                    onTestCreated = {
                                        loadAllData()
                                        scope.launch { snackbarHostState.showSnackbar("Test created successfully!") }
                                    },
                                    onQuestionAdded = { addedTestId ->
                                        testQuestionCounts = testQuestionCounts + (addedTestId to ((testQuestionCounts[addedTestId] ?: 0) + 1))
                                        scope.launch { snackbarHostState.showSnackbar("Question saved to Supabase!") }
                                    }
                                )
                            }
                        }
                        // Tab 4: Create / Add (for Super Admin)
                        else if (selectedTab == 4 && isSuperAdmin) {
                            AdminCreateContentSection(
                                testsList = testsList,
                                repository = repository,
                                onTestCreated = {
                                    loadAllData()
                                    scope.launch { snackbarHostState.showSnackbar("Test created successfully!") }
                                },
                                onQuestionAdded = { addedTestId ->
                                    testQuestionCounts = testQuestionCounts + (addedTestId to ((testQuestionCounts[addedTestId] ?: 0) + 1))
                                    scope.launch { snackbarHostState.showSnackbar("Question saved to Supabase!") }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal: View & Manage Questions dialog
    if (viewingQuestionsTest != null) {
        val test = viewingQuestionsTest!!
        AlertDialog(
            onDismissRequest = { viewingQuestionsTest = null },
            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp).testTag("admin_view_questions_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(6.dp), color = MitraNavyPrimary) {
                                Text(
                                    text = "Test $viewingQuestionsTestIndex",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = test.testName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MitraNavyPrimary,
                                softWrap = true
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Total Questions: ${testQuestionsList.size}",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                    IconButton(onClick = { AppSoundManager.playClick(); viewingQuestionsTest = null }) {
                        Icon(Icons.Default.Clear, contentDescription = "Close")
                    }
                }
            },
            text = {
                Box(modifier = Modifier.height(400.dp)) {
                    if (isLoadingQuestions) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                        }
                    } else if (testQuestionsList.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = "No questions added to this test yet.",
                                textAlign = TextAlign.Center,
                                color = MitraTextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(testQuestionsList, key = { _, it -> it.id ?: 0L }) { index, q ->
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MitraBgLight),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Surface(shape = RoundedCornerShape(6.dp), color = MitraNavyPrimary) {
                                                Text(
                                                    text = "Question ${index + 1}",
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                IconButton(onClick = { AppSoundManager.playClick(); questionToEdit = q }, modifier = Modifier.size(28.dp)) {
                                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MitraNavyPrimary, modifier = Modifier.size(18.dp))
                                                }
                                                if (isSuperAdmin) {
                                                    IconButton(onClick = { AppSoundManager.playClick(); questionToDelete = q }, modifier = Modifier.size(28.dp)) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MitraError, modifier = Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        if (!q.passageText.isNullOrBlank()) {
                                            QuestionPassageDisplay(passageText = q.passageText)
                                            Spacer(modifier = Modifier.height(6.dp))
                                        }
                                        if (!q.imageUrl.isNullOrBlank()) {
                                            QuestionImageDisplay(imageUrl = q.imageUrl)
                                            Spacer(modifier = Modifier.height(6.dp))
                                        }
                                        Text(text = q.questionText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MitraTextPrimary, lineHeight = 22.sp)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        val correct = q.normalizedCorrectOption()
                                        listOf("A" to q.optionA, "B" to q.optionB, "C" to q.optionC, "D" to q.optionD).forEach { (opt, txt) ->
                                            val isCorrect = opt.equals(correct, ignoreCase = true)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isCorrect) MitraGreenLight else Color.White,
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                            ) {
                                                Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "($opt) $txt",
                                                        fontSize = 12.sp,
                                                        fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isCorrect) MitraGreen else MitraTextSecondary,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    if (isCorrect) {
                                                        Surface(shape = RoundedCornerShape(4.dp), color = MitraGreen) {
                                                            Text(text = "✓ Correct", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(text = "Close", onClick = { AppSoundManager.playClick(); viewingQuestionsTest = null })
            }
        )
    }

    // Modal: Confirmation Dialog for Question Deletion (Super Admin only)
    if (questionToDelete != null && isSuperAdmin) {
        val q = questionToDelete!!
        AlertDialog(
            onDismissRequest = { questionToDelete = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MitraError, modifier = Modifier.size(36.dp)) },
            title = { Text(text = "Delete Question?", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MitraError) },
            text = { Text(text = "Are you sure you want to delete this question?\n${q.questionText}", fontSize = 14.sp) },
            confirmButton = {
                TextButton(
                    onClick = { AppSoundManager.playClick();
                        val qId = q.id
                        questionToDelete = null
                        if (qId != null) {
                            scope.launch {
                                val delQ = repository.deleteQuestion(qId, user, imageUrl = q.imageUrl)
                                if (delQ is Resource.Success) {
                                    val updatedQuestions = testQuestionsList.filter { it.id != qId }
                                    testQuestionsList = updatedQuestions
                                    (q.testId ?: viewingQuestionsTest?.id)?.let { tId ->
                                        testQuestionCounts = testQuestionCounts + (tId to updatedQuestions.size)
                                    }
                                    snackbarHostState.showSnackbar("Question deleted successfully!")
                                } else if (delQ is Resource.Error) {
                                    snackbarHostState.showSnackbar(delQ.message)
                                }
                            }
                        }
                    }
                ) { Text("Delete", color = MitraError, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); questionToDelete = null }) { Text("Cancel", color = MitraTextSecondary) }
            }
        )
    }

    // Modal: Edit Test Details Dialog
    if (testToEdit != null) {
        val t = testToEdit!!
        val context = LocalContext.current
        var editTestName by remember(t) { mutableStateOf(t.testName) }
        var editDurationMinutes by remember(t) { mutableStateOf(t.duration.toString()) }
        var editTestDate by remember(t) { mutableStateOf(t.getFormattedDateOnly() ?: "") }
        var editTestDay by remember(t) { mutableStateOf(t.testDay ?: "") }
        var editDayDropdownExpanded by remember { mutableStateOf(false) }
        var editError by remember { mutableStateOf<String?>(null) }
        var isSavingTest by remember { mutableStateOf(false) }
        val daysList = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

        AlertDialog(
            onDismissRequest = { if (!isSavingTest) testToEdit = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Edit Test", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MitraNavyPrimary) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = editTestName,
                        onValueChange = { editTestName = it; editError = null },
                        label = { Text("Test Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editDurationMinutes,
                        onValueChange = { editDurationMinutes = it.filter { c -> c.isDigit() }; editError = null },
                        label = { Text("Duration (Minutes)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Manual Test Date Field with Calendar Picker
                    OutlinedTextField(
                        value = editTestDate,
                        onValueChange = { editTestDate = it; editError = null },
                        label = { Text("Test Date (DD/MM/YYYY)") },
                        placeholder = { Text("e.g. 20/01/2025") },
                        trailingIcon = {
                            IconButton(onClick = { AppSoundManager.playClick();
                                val cal = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        editTestDate = String.format(Locale.US, "%02d/%02d/%04d", d, m + 1, y)
                                        editError = null
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = "Pick Date",
                                    tint = MitraNavyPrimary
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Manual Test Day Selection (Independent of Date)
                    ExposedDropdownMenuBox(
                        expanded = editDayDropdownExpanded,
                        onExpandedChange = { editDayDropdownExpanded = !editDayDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = editTestDay,
                            onValueChange = { editTestDay = it; editError = null },
                            label = { Text("Test Day (e.g. Sunday)") },
                            placeholder = { Text("Select or type Day") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = editDayDropdownExpanded) },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = editDayDropdownExpanded,
                            onDismissRequest = { editDayDropdownExpanded = false }
                        ) {
                            daysList.forEach { day ->
                                DropdownMenuItem(
                                    text = { Text(day) },
                                    onClick = { AppSoundManager.playClick();
                                        editTestDay = day
                                        editDayDropdownExpanded = false
                                        editError = null
                                    }
                                )
                            }
                        }
                    }

                    if (editError != null) {
                        Text(text = editError!!, color = MitraError, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Changes",
                    onClick = { AppSoundManager.playClick();
                        val nameClean = editTestName.trim()
                        val dur = editDurationMinutes.toIntOrNull() ?: 0
                        if (nameClean.isBlank() || dur <= 0) {
                            editError = "Valid name and duration required"
                            return@MitraPrimaryButton
                        }
                        val cleanDate = editTestDate.trim().ifBlank { null }
                        val cleanDay = editTestDay.trim().ifBlank { null }
                        isSavingTest = true
                        scope.launch {
                            val res = repository.updateTest(t.id ?: 0L, nameClean, dur, cleanDate, cleanDay)
                            isSavingTest = false
                            if (res is Resource.Success) {
                                testsList = testsList.map {
                                    if (it.id == t.id) it.copy(
                                        testName = nameClean,
                                        duration = dur,
                                        testDate = cleanDate,
                                        testDay = cleanDay
                                    ) else it
                                }
                                testToEdit = null
                                snackbarHostState.showSnackbar("Test updated successfully!")
                            } else if (res is Resource.Error) {
                                editError = res.message
                            }
                        }
                    },
                    isLoading = isSavingTest
                )
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); if (!isSavingTest) testToEdit = null }) { Text("Cancel") }
            }
        )
    }

    // Modal: Edit Question Dialog
    if (questionToEdit != null) {
        val q = questionToEdit!!
        val context = LocalContext.current
        var editQText by remember(q) { mutableStateOf(q.questionText) }
        var editPassage by remember(q) { mutableStateOf(q.passageText.orEmpty()) }
        var editOptA by remember(q) { mutableStateOf(q.optionA) }
        var editOptB by remember(q) { mutableStateOf(q.optionB) }
        var editOptC by remember(q) { mutableStateOf(q.optionC) }
        var editOptD by remember(q) { mutableStateOf(q.optionD) }
        var editCorrect by remember(q) { mutableStateOf(q.normalizedCorrectOption()) }
        var selectedImageUri by remember(q) { mutableStateOf<Uri?>(null) }
        var existingImageUrl by remember(q) { mutableStateOf<String?>(q.imageUrl) }
        var editQError by remember { mutableStateOf<String?>(null) }
        var isSavingQ by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isSavingQ) questionToEdit = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Edit Question", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MitraNavyPrimary) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Optional Paragraph/Poem Field
                    OutlinedTextField(
                        value = editPassage,
                        onValueChange = { editPassage = it },
                        label = { Text("Paragraph/Poem (Optional)") },
                        placeholder = { Text("Enter reading comprehension paragraph/poem for this question...") },
                        minLines = 2,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth().testTag("edit_passage_input")
                    )

                    OutlinedTextField(
                        value = editQText,
                        onValueChange = { editQText = it },
                        label = { Text("Question Text") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("edit_question_input")
                    )

                    // Optional Question Image Picker
                    QuestionImagePicker(
                        selectedUri = selectedImageUri,
                        existingUrl = existingImageUrl,
                        onImageSelected = { selectedImageUri = it },
                        onRemoveImage = {
                            selectedImageUri = null
                            existingImageUrl = null
                        }
                    )

                    OutlinedTextField(value = editOptA, onValueChange = { editOptA = it }, label = { Text("Option A") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editOptB, onValueChange = { editOptB = it }, label = { Text("Option B") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editOptC, onValueChange = { editOptC = it }, label = { Text("Option C") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editOptD, onValueChange = { editOptD = it }, label = { Text("Option D") }, modifier = Modifier.fillMaxWidth())
                    Text("Select Correct Option:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("A", "B", "C", "D").forEach { opt ->
                            val isSel = editCorrect == opt
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MitraGreen else MitraBgLight,
                                modifier = Modifier.weight(1f).clickable { editCorrect = opt }
                            ) {
                                Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                    Text(opt, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else MitraTextPrimary)
                                }
                            }
                        }
                    }
                    if (editQError != null) Text(editQError!!, color = MitraError, fontSize = 12.sp)
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Question",
                    onClick = { AppSoundManager.playClick();
                        if (editQText.isBlank() || editOptA.isBlank() || editOptB.isBlank() || editOptC.isBlank() || editOptD.isBlank()) {
                            editQError = "All fields are required"
                            return@MitraPrimaryButton
                        }
                        isSavingQ = true
                        editQError = null
                        scope.launch {
                            val cleanPassage = editPassage.trim().ifBlank { null }

                            if (selectedImageUri != null) {
                                // A) REPLACE EXISTING IMAGE (or add to a question that had no image)
                                // 1. Upload NEW image first
                                val uploadRes = repository.uploadQuestionImage(selectedImageUri!!, context)
                                if (!uploadRes.isSuccess) {
                                    isSavingQ = false
                                    editQError = "Image upload failed: ${uploadRes.exceptionOrNull()?.localizedMessage ?: "Unknown error"}"
                                    return@launch
                                }
                                // 2. Confirm new upload succeeded and obtain URL
                                val newImageUrl = uploadRes.getOrNull()
                                val oldImageToDelete = q.imageUrl?.takeIf { it.isNotBlank() && it != newImageUrl }

                                // 3. Update question's image_url to the new URL in database first
                                val res = repository.updateQuestion(
                                    questionId = q.id ?: 0L,
                                    questionText = editQText.trim(),
                                    optionA = editOptA.trim(),
                                    optionB = editOptB.trim(),
                                    optionC = editOptC.trim(),
                                    optionD = editOptD.trim(),
                                    correctOption = editCorrect,
                                    imageUrl = newImageUrl,
                                    passageText = cleanPassage
                                )

                                isSavingQ = false
                                if (res is Resource.Success) {
                                    val updatedItem = res.data
                                    testQuestionsList = testQuestionsList.map { if (it.id == q.id) updatedItem else it }
                                    questionToEdit = null

                                    // 4. Only after database update succeeds, delete the OLD Storage object
                                    if (oldImageToDelete != null) {
                                        val delOldRes = repository.deleteQuestionImage(oldImageToDelete)
                                        if (delOldRes.isFailure) {
                                            // 5. If old-image deletion fails:
                                            // DO NOT delete new image. DO NOT restore old URL. Keep new question image working.
                                            // Log/report the exact deletion error so it is not silently ignored.
                                            val delErr = delOldRes.exceptionOrNull()?.localizedMessage ?: "Unknown storage error"
                                            android.util.Log.w("AdminHomeScreen", "Question updated with new image, but old image deletion failed: $delErr")
                                            snackbarHostState.showSnackbar("Question updated, but old image cleanup failed: $delErr")
                                        } else {
                                            snackbarHostState.showSnackbar("Question and image updated successfully!")
                                        }
                                    } else {
                                        snackbarHostState.showSnackbar("Question updated successfully!")
                                    }
                                } else if (res is Resource.Error) {
                                    editQError = res.message
                                }
                            } else if (existingImageUrl.isNullOrBlank() && !q.imageUrl.isNullOrBlank()) {
                                // B) REMOVE IMAGE WITHOUT REPLACING IT
                                // 1. Identify old Storage path: q.imageUrl
                                // 2. Delete old Storage object successfully BEFORE updating DB to NULL
                                val delOldRes = repository.deleteQuestionImage(q.imageUrl)
                                if (delOldRes.isFailure) {
                                    // 4. If Storage deletion fails:
                                    // do NOT silently set database URL to NULL
                                    // show/report the actual error
                                    // keep existing image URL so image is not lost
                                    isSavingQ = false
                                    val delErr = delOldRes.exceptionOrNull()?.localizedMessage ?: "Storage deletion failed"
                                    editQError = "Failed to remove image from storage: $delErr"
                                    return@launch
                                }

                                // 3. Only after successful deletion, update questions.image_url to NULL
                                val res = repository.updateQuestion(
                                    questionId = q.id ?: 0L,
                                    questionText = editQText.trim(),
                                    optionA = editOptA.trim(),
                                    optionB = editOptB.trim(),
                                    optionC = editOptC.trim(),
                                    optionD = editOptD.trim(),
                                    correctOption = editCorrect,
                                    imageUrl = null,
                                    passageText = cleanPassage
                                )

                                isSavingQ = false
                                if (res is Resource.Success) {
                                    val updatedItem = res.data
                                    testQuestionsList = testQuestionsList.map { if (it.id == q.id) updatedItem else it }
                                    questionToEdit = null
                                    snackbarHostState.showSnackbar("Image removed and question updated successfully!")
                                } else if (res is Resource.Error) {
                                    editQError = res.message
                                }
                            } else {
                                // Neither replaced nor removed (image kept unchanged, or question had no image)
                                val res = repository.updateQuestion(
                                    questionId = q.id ?: 0L,
                                    questionText = editQText.trim(),
                                    optionA = editOptA.trim(),
                                    optionB = editOptB.trim(),
                                    optionC = editOptC.trim(),
                                    optionD = editOptD.trim(),
                                    correctOption = editCorrect,
                                    imageUrl = existingImageUrl,
                                    passageText = cleanPassage
                                )

                                isSavingQ = false
                                if (res is Resource.Success) {
                                    val updatedItem = res.data
                                    testQuestionsList = testQuestionsList.map { if (it.id == q.id) updatedItem else it }
                                    questionToEdit = null
                                    snackbarHostState.showSnackbar("Question updated successfully!")
                                } else if (res is Resource.Error) {
                                    editQError = res.message
                                }
                            }
                        }
                    },
                    isLoading = isSavingQ
                )
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); if (!isSavingQ) questionToEdit = null }) { Text("Cancel") }
            }
        )
    }
}

/**
 * Common helper to compute the test sequence number (Kram) consistently across Test, Result, and Create sections.
 * Matches Test section ordering: latest test has highest number, oldest has Test 1.
 */
fun getTestSequenceNumber(testId: Long, tests: List<TestItem>): Int {
    val idx = tests.indexOfFirst { it.id == testId }
    return if (idx >= 0) tests.size - idx else 1
}

/**
 * Single Test Item Card for Admin with "Take Test" (Feature 1) + Toggle Status + View Questions + Edit + Delete
 */
@Composable
private fun AdminTestItemCard(
    test: TestItem,
    testSequenceNumber: Int,
    isSuperAdmin: Boolean = false,
    completedResult: EnrichedResult? = null,
    totalQuestionsCount: Int? = null,
    onTakeTest: () -> Unit,
    onToggleActive: (Boolean) -> Unit,
    onViewQuestions: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val isActive = test.isTestActive
    val isCompleted = completedResult != null

    Card(
        modifier = Modifier.fillMaxWidth().testTag("admin_test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MitraNavyPrimary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Text(
                            text = "Test $testSequenceNumber",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary,
                        softWrap = true
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Duration: ${test.duration} minutes",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isCompleted) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MitraGreenLight
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MitraGreen,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Score: ${completedResult.score.toInt()}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MitraGreen
                                )
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isActive) MitraGreenLight else MitraBgLight
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(8.dp).background(if (isActive) MitraGreen else MitraTextMuted, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isActive) "Active" else "Deactive",
                                color = if (isActive) MitraGreen else MitraTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dynamic Date and Duration Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val formattedDate = test.getFormattedDate()
                if (!formattedDate.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = MitraNavyPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = formattedDate,
                                fontSize = 12.sp,
                                color = MitraNavyPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F5F9)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = MitraTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${test.duration} Min",
                            fontSize = 12.sp,
                            color = MitraTextSecondary,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Active Toggle Row
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MitraBgLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isActive) Icons.Default.PlayCircle else Icons.Default.PauseCircle,
                            contentDescription = null,
                            tint = if (isActive) MitraGreen else MitraTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isActive) "Status: Active" else "Status: Deactive",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isActive) MitraGreen else MitraTextSecondary
                        )
                    }
                    Switch(
                        checked = isActive,
                        onCheckedChange = { onToggleActive(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MitraGreen,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = MitraBorder
                        ),
                        modifier = Modifier.testTag("toggle_test_active_${test.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Attempted Test Status Card (matching Student Home Screen exactly)
            if (isCompleted) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MitraGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MitraGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Test Completed",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraGreen
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Take/Retake Test Button
            MitraSuccessButton(
                text = if (isCompleted) "Retake Test" else "Take Test",
                onClick = onTakeTest,
                icon = if (isCompleted) Icons.Default.Refresh else Icons.Default.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                height = 42.dp,
                testTag = "admin_take_test_button_${test.id}"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Questions, Edit, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MitraOutlinedButton(
                    text = "Questions",
                    onClick = onViewQuestions,
                    icon = Icons.Default.FormatListNumbered,
                    modifier = Modifier.weight(1f),
                    height = 38.dp,
                    fontSize = 12.sp,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                    testTag = "view_questions_button_${test.id}"
                )
                MitraOutlinedButton(
                    text = "Edit",
                    onClick = onEdit,
                    icon = Icons.Default.Edit,
                    modifier = if (isSuperAdmin) Modifier.weight(0.9f) else Modifier.weight(1f),
                    height = 38.dp,
                    fontSize = 12.sp,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                    testTag = "edit_test_button_${test.id}"
                )
                if (isSuperAdmin) {
                    MitraOutlinedButton(
                        text = "Delete",
                        onClick = { AppSoundManager.playClick(); showDeleteConfirm = true },
                        icon = Icons.Default.Delete,
                        borderColor = MitraErrorLight,
                        contentColor = MitraError,
                        modifier = Modifier.weight(0.95f),
                        height = 38.dp,
                        fontSize = 12.sp,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                        testTag = "delete_test_button_${test.id}"
                    )
                }
            }
        }
    }

    if (showDeleteConfirm && isSuperAdmin) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MitraError, modifier = Modifier.size(36.dp)) },
            title = { Text("Delete Test?", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MitraError) },
            text = { Text("Are you sure you want to delete '${test.testName}'? Associated questions and results will be removed.") },
            confirmButton = {
                TextButton(onClick = { AppSoundManager.playClick(); showDeleteConfirm = false; onDelete() }) {
                    Text("Delete", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

/**
 * Feature 3: Complete Results Dashboard Section integrated directly from TEST MITRA RESULTS (ZIP 2)
 * Strictly Admin / Super Admin only.
 */
@Composable
private fun AdminResultsDashboardSection(
    testsList: List<TestItem>,
    repository: TestMitraRepository
) {
    var selectedTest by remember { mutableStateOf<TestItem?>(testsList.firstOrNull()) }
    var resultsList by remember { mutableStateOf<List<ResultModel>>(emptyList()) }
    var isLoadingResults by remember { mutableStateOf(false) }
    var resultStudentSearch by remember { mutableStateOf("") }
    var dropdownExpanded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun loadResultsForSelectedTest(t: TestItem) {
        isLoadingResults = true
        scope.launch {
            val res = repository.getResultsForTestAdmin(t.id ?: 0L, t.totalMarks)
            isLoadingResults = false
            if (res is Resource.Success) {
                resultsList = res.data
            } else {
                resultsList = emptyList()
            }
        }
    }

    LaunchedEffect(testsList) {
        if (selectedTest == null && testsList.isNotEmpty()) {
            selectedTest = testsList.first()
        }
        selectedTest?.let { loadResultsForSelectedTest(it) }
    }

    val filteredResults = remember(resultsList, resultStudentSearch) {
        if (resultStudentSearch.isBlank()) resultsList
        else resultsList.filter { it.studentName.contains(resultStudentSearch.trim(), ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Test Selection Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Selector Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT TEST",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraNavyPrimary
                    )
                    IconButton(
                        onClick = { AppSoundManager.playClick(); selectedTest?.let { loadResultsForSelectedTest(it) } },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = MitraNavyPrimary, modifier = Modifier.size(18.dp))
                    }
                }

                // Dropdown trigger box with Test Sequence Kram
                val selSeqNumber = selectedTest?.let { getTestSequenceNumber(it.id ?: 0L, testsList) } ?: 1
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF1F5F9))
                        .clickable { dropdownExpanded = true }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (selectedTest != null) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MitraNavyPrimary,
                                        modifier = Modifier.padding(end = 8.dp)
                                    ) {
                                        Text(
                                            text = "Test $selSeqNumber",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = selectedTest?.testName ?: "Select Test...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MitraTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Duration: ${selectedTest?.duration ?: 0} min",
                                fontSize = 12.sp,
                                color = MitraNavyPrimary
                            )
                        }
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = MitraTextPrimary)
                    }

                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier.background(Color.White).width(300.dp)
                    ) {
                        testsList.forEach { t ->
                            val seq = getTestSequenceNumber(t.id ?: 0L, testsList)
                            val isSelected = t.id == selectedTest?.id
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isSelected) MitraGreen else MitraNavyPrimary,
                                            modifier = Modifier.padding(end = 10.dp)
                                        ) {
                                            Text(
                                                text = "Test $seq",
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = t.testName,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 14.sp,
                                                color = if (isSelected) MitraNavyPrimary else MitraTextPrimary
                                            )
                                            Text(
                                                text = "${t.duration} min",
                                                fontSize = 11.sp,
                                                color = MitraTextMuted
                                            )
                                        }
                                    }
                                },
                                onClick = { AppSoundManager.playClick();
                                    dropdownExpanded = false
                                    selectedTest = t
                                    loadResultsForSelectedTest(t)
                                }
                            )
                        }
                    }
                }

                // Student Search Bar
                OutlinedTextField(
                    value = resultStudentSearch,
                    onValueChange = { resultStudentSearch = it },
                    placeholder = { Text("Filter student by name...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MitraTextMuted) },
                    trailingIcon = {
                        if (resultStudentSearch.isNotBlank()) {
                            IconButton(onClick = { AppSoundManager.playClick(); resultStudentSearch = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MitraNavyPrimary,
                        unfocusedBorderColor = MitraBorder,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
            }
        }

        // Section Title & Badge
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Icon(Icons.Default.Assessment, contentDescription = null, tint = MitraNavyPrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Text(
                        text = "STUDENT PERFORMANCE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MitraTextPrimary,
                        letterSpacing = 0.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    selectedTest?.let {
                        val seq = getTestSequenceNumber(it.id ?: 0L, testsList)
                        Text(
                            text = "Test $seq: ${it.testName}",
                            fontSize = 11.sp,
                            color = MitraNavyPrimary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MitraNavyPrimary
            ) {
                Text(
                    text = "${filteredResults.size} Records",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // Content
        if (isLoadingResults) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MitraNavyPrimary)
            }
        } else if (filteredResults.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Assignment, contentDescription = null, tint = MitraTextMuted, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (resultStudentSearch.isNotBlank()) "No records match search" else "No results for this test yet",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MitraTextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f).testTag("admin_results_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(filteredResults, key = { _, it -> it.id }) { index, result ->
                    AdminStudentResultCard(rank = index + 1, result = result)
                }
            }
        }
    }
}

/**
 * Result Card from TEST MITRA RESULTS (ZIP 2) with 4-color gradient ranks, Trophy score badge
 */
@Composable
private fun AdminStudentResultCard(rank: Int, result: ResultModel) {
    val rankFormatted = remember(rank) { String.format("%02d", rank) }
    val dateFormatted = remember(result.createdAt) {
        if (result.createdAt.isNullOrEmpty()) "Today"
        else TestItem.formatToDdMmYyyy(result.createdAt) ?: try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = parser.parse(result.createdAt.take(10)) ?: return@remember "Today"
            val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            formatter.format(date)
        } catch (_: Exception) {
            result.createdAt.take(10)
        }
    }

    val rankGradient = remember(rank) {
        when ((rank - 1) % 4) {
            0 -> Brush.verticalGradient(listOf(Color(0xFF0284C7), Color(0xFF0EA5E9)))
            1 -> Brush.verticalGradient(listOf(Color(0xFF16A34A), Color(0xFF22C55E)))
            2 -> Brush.verticalGradient(listOf(Color(0xFF7C3AED), Color(0xFF8B5CF6)))
            else -> Brush.verticalGradient(listOf(Color(0xFFEA580C), Color(0xFFF59E0B)))
        }
    }

    val iconTint = remember(rank) {
        when ((rank - 1) % 4) {
            0 -> Color(0xFF0284C7)
            1 -> Color(0xFF16A34A)
            2 -> Color(0xFF7C3AED)
            else -> Color(0xFFEA580C)
        }
    }

    val score = result.score
    val scoreBadgeBg = if (score >= 10) Color(0xFFDCFCE7) else Color(0xFFEFF6FF)
    val scoreBadgeText = if (score >= 10) Color(0xFF15803D) else Color(0xFF1D4ED8)

    Card(
        modifier = Modifier.fillMaxWidth().testTag("admin_result_card_$rank"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            // Rank Box
            Box(
                modifier = Modifier.width(58.dp).height(80.dp).background(rankGradient),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rankFormatted,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = Color.White,
                    fontFamily = FontFamily.SansSerif
                )
            }

            // Student Info
            Column(
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
                    Text(
                        text = result.studentName.uppercase(Locale.getDefault()),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = MitraTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEFF6FF),
                    border = BorderStroke(1.dp, Color(0xFFDBEAFE))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(12.dp))
                        Text(text = dateFormatted, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                    }
                }
            }

            // Score Badge with Trophy
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = scoreBadgeBg,
                modifier = Modifier.padding(end = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = "Trophy", tint = scoreBadgeText, modifier = Modifier.size(18.dp))
                    Text(
                        text = if (score % 1.0 == 0.0) "${score.toInt()}" else "$score",
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = scoreBadgeText,
                        fontFamily = FontFamily.SansSerif
                    )
                }
            }
        }
    }
}

@Composable
private fun AdminStudentsSection(
    currentUser: User,
    usersList: List<User>,
    repository: TestMitraRepository,
    onStudentAdded: () -> Unit,
    onStudentUpdated: () -> Unit,
    onStudentDeleted: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var studentToEdit by remember { mutableStateOf<User?>(null) }
    var userToDelete by remember { mutableStateOf<User?>(null) }
    val isSuperAdmin = currentUser.isSuperAdminUser
    val scope = rememberCoroutineScope()

    val students = remember(usersList, searchQuery) {
        val list = usersList.filter { !it.isTeacherOrAdmin }
        if (searchQuery.isBlank()) list
        else list.filter {
            it.mobileNumber.contains(searchQuery.trim()) ||
            (it.name != null && it.name.contains(searchQuery.trim(), ignoreCase = true))
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!isSuperAdmin) {
            Surface(shape = RoundedCornerShape(12.dp), color = MitraOrangeLight, modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MitraOrange, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Student management is restricted to Super Admin only.",
                        fontSize = 12.sp,
                        color = MitraNavyDark
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search name or mobile...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MitraNavyPrimary) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { AppSoundManager.playClick(); searchQuery = "" }) { Icon(Icons.Default.Clear, contentDescription = null) }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MitraNavyPrimary,
                    unfocusedBorderColor = MitraBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )
            if (isSuperAdmin) {
                MitraSuccessButton(
                    text = "Add",
                    onClick = { AppSoundManager.playClick(); showAddDialog = true },
                    icon = Icons.Default.PersonAdd,
                    height = 54.dp
                )
            }
        }

        if (students.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text(text = "No students found.", color = MitraTextSecondary)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(students, key = { it.id ?: 0L }) { student ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = MitraNavyPrimary.copy(alpha = 0.1f)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = MitraNavyPrimary, modifier = Modifier.size(22.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = student.name ?: "Student #${student.id ?: "-"}",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary
                                    )
                                    Text(
                                        text = "Mobile: ${student.mobileNumber}",
                                        fontSize = 12.sp,
                                        color = MitraTextSecondary
                                    )
                                }
                            }
                            if (isSuperAdmin) {
                                Row {
                                    IconButton(onClick = { AppSoundManager.playClick(); studentToEdit = student }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MitraNavyPrimary)
                                    }
                                    IconButton(onClick = { AppSoundManager.playClick(); userToDelete = student }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MitraError)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Add Student Dialog
    if (showAddDialog && isSuperAdmin) {
        var nameInput by remember { mutableStateOf("") }
        var mobileInput by remember { mutableStateOf("") }
        var passwordInput by remember { mutableStateOf("") }
        var addError by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isSaving) showAddDialog = false },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Add Student", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Student Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = mobileInput,
                        onValueChange = { if (it.length <= 10 && it.all { c -> c.isDigit() }) mobileInput = it },
                        label = { Text("Mobile Number (10 digits)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (addError != null) Text(addError!!, color = MitraError, fontSize = 12.sp)
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Student",
                    onClick = { AppSoundManager.playClick();
                        if (nameInput.isBlank() || mobileInput.length != 10 || passwordInput.isBlank()) {
                            addError = "Please fill all fields correctly"
                            return@MitraPrimaryButton
                        }
                        isSaving = true
                        scope.launch {
                            val res = repository.registerUser(nameInput.trim(), mobileInput.trim(), passwordInput.trim(), "student", currentUser)
                            isSaving = false
                            if (res is Resource.Success) {
                                showAddDialog = false
                                onStudentAdded()
                            } else if (res is Resource.Error) {
                                addError = res.message
                            }
                        }
                    },
                    isLoading = isSaving
                )
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); if (!isSaving) showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Modal: Edit Student Dialog
    if (studentToEdit != null && isSuperAdmin) {
        val st = studentToEdit!!
        var editName by remember(st) { mutableStateOf(st.name ?: "") }
        var editPassword by remember { mutableStateOf("") }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isSaving) studentToEdit = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Edit Student", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Mobile: ${st.mobileNumber}", fontSize = 13.sp, color = MitraTextSecondary)
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editPassword, onValueChange = { editPassword = it }, label = { Text("New Password (optional)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Update",
                    onClick = { AppSoundManager.playClick();
                        if (editName.isBlank()) return@MitraPrimaryButton
                        isSaving = true
                        scope.launch {
                            val res = repository.updateUser(st.id ?: 0L, editName.trim(), editPassword.trim().ifBlank { null }, currentUser)
                            isSaving = false
                            if (res is Resource.Success) {
                                studentToEdit = null
                                onStudentUpdated()
                            }
                        }
                    },
                    isLoading = isSaving
                )
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); if (!isSaving) studentToEdit = null }) { Text("Cancel") }
            }
        )
    }

    // Modal: Delete Student Dialog
    if (userToDelete != null && isSuperAdmin) {
        val st = userToDelete!!
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Delete Student?", fontWeight = FontWeight.Bold, color = MitraError) },
            text = { Text("Are you sure you want to delete ${st.name ?: st.mobileNumber}?") },
            confirmButton = {
                TextButton(onClick = { AppSoundManager.playClick();
                    val sId = st.id
                    userToDelete = null
                    if (sId != null) {
                        scope.launch {
                            repository.deleteUser(sId, currentUser)
                            onStudentDeleted()
                        }
                    }
                }) { Text("Delete", color = MitraError, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { AppSoundManager.playClick(); userToDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AdminManagementSection(
    currentUser: User,
    usersList: List<User>,
    repository: TestMitraRepository,
    onAdminAdded: () -> Unit,
    onAdminUpdated: () -> Unit,
    onAdminDeleted: () -> Unit,
    onStatusChanged: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddAdminDialog by remember { mutableStateOf(false) }
    var adminToEdit by remember { mutableStateOf<User?>(null) }
    var adminToDelete by remember { mutableStateOf<User?>(null) }
    var adminToToggleStatus by remember { mutableStateOf<User?>(null) }
    val scope = rememberCoroutineScope()

    val admins = remember(usersList, searchQuery) {
        val list = usersList.filter { it.isTeacherOrAdmin }
        if (searchQuery.isBlank()) list
        else list.filter {
            it.mobileNumber.contains(searchQuery.trim()) ||
            (it.name != null && it.name.contains(searchQuery.trim(), ignoreCase = true))
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        MitraPrimaryButton(
            text = "+ Add Admin",
            onClick = { AppSoundManager.playClick(); showAddAdminDialog = true },
            icon = Icons.Default.AdminPanelSettings,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search admin name or mobile...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MitraNavyPrimary) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MitraNavyPrimary,
                unfocusedBorderColor = MitraBorder,
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
            )
        )

        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(admins, key = { it.id ?: 0L }) { adminItem ->
                val isRootSuper = adminItem.isSuperAdminUser
                val isDeactivated = adminItem.deviceId?.trim() == "DEACTIVATED"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Surface(
                                    modifier = Modifier.size(42.dp),
                                    shape = CircleShape,
                                    color = if (isRootSuper) MitraNavyPrimary.copy(alpha = 0.15f) else MitraOrangeLight
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(if (isRootSuper) Icons.Default.Shield else Icons.Default.AdminPanelSettings, contentDescription = null, tint = if (isRootSuper) MitraNavyPrimary else MitraOrange)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = adminItem.name ?: "Admin", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "Mobile: ${adminItem.mobileNumber}", fontSize = 12.sp, color = MitraTextSecondary)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isRootSuper) MitraNavyPrimary else if (isDeactivated) MitraErrorLight else MitraGreenLight
                            ) {
                                Text(
                                    text = if (isRootSuper) "SUPER ADMIN" else if (isDeactivated) "Deactivated" else "ADMIN",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isRootSuper) Color.White else if (isDeactivated) MitraError else MitraGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (!isRootSuper) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                if (currentUser.isSuperAdminUser) {
                                    TextButton(onClick = { AppSoundManager.playClick(); adminToToggleStatus = adminItem }) {
                                        Text(if (isDeactivated) "Activate" else "Deactivate", color = if (isDeactivated) MitraGreen else MitraOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    IconButton(onClick = { AppSoundManager.playClick(); adminToEdit = adminItem }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MitraNavyPrimary)
                                    }
                                    IconButton(onClick = { AppSoundManager.playClick(); adminToDelete = adminItem }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MitraError)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAdminDialog) {
        var aName by remember { mutableStateOf("") }
        var aMobile by remember { mutableStateOf("") }
        var aPass by remember { mutableStateOf("") }
        var aErr by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isSaving) showAddAdminDialog = false },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Add Admin", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = aName, onValueChange = { aName = it }, label = { Text("Admin Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = aMobile, onValueChange = { if (it.length <= 10 && it.all { c -> c.isDigit() }) aMobile = it }, label = { Text("Mobile Number (10 digits)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = aPass, onValueChange = { aPass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
                    if (aErr != null) Text(aErr!!, color = MitraError, fontSize = 12.sp)
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Admin",
                    onClick = { AppSoundManager.playClick();
                        if (aName.isBlank() || aMobile.length != 10 || aPass.isBlank()) {
                            aErr = "All fields required"
                            return@MitraPrimaryButton
                        }
                        isSaving = true
                        scope.launch {
                            val res = repository.registerUser(aName.trim(), aMobile.trim(), aPass.trim(), "admin", currentUser)
                            isSaving = false
                            if (res is Resource.Success) {
                                showAddAdminDialog = false
                                onAdminAdded()
                            } else if (res is Resource.Error) {
                                aErr = res.message
                            }
                        }
                    },
                    isLoading = isSaving
                )
            },
            dismissButton = { TextButton(onClick = { AppSoundManager.playClick(); if (!isSaving) showAddAdminDialog = false }) { Text("Cancel") } }
        )
    }

    if (adminToToggleStatus != null) {
        val a = adminToToggleStatus!!
        val isDeact = a.deviceId?.trim() == "DEACTIVATED"
        AlertDialog(
            onDismissRequest = { adminToToggleStatus = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text(if (isDeact) "Activate Admin?" else "Deactivate Admin?") },
            text = { Text("Update login access for ${a.name ?: a.mobileNumber}?") },
            confirmButton = {
                TextButton(onClick = { AppSoundManager.playClick();
                    adminToToggleStatus = null
                    scope.launch {
                        repository.toggleAdminActiveStatus(a.id ?: 0L, !isDeact, currentUser)
                        onStatusChanged()
                    }
                }) { Text(if (isDeact) "Activate" else "Deactivate", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { AppSoundManager.playClick(); adminToToggleStatus = null }) { Text("Cancel") } }
        )
    }

    if (adminToDelete != null) {
        val a = adminToDelete!!
        AlertDialog(
            onDismissRequest = { adminToDelete = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = { Text("Delete Admin?", fontWeight = FontWeight.Bold, color = MitraError) },
            text = { Text("Permanently delete admin ${a.name ?: a.mobileNumber}?") },
            confirmButton = {
                TextButton(onClick = { AppSoundManager.playClick();
                    val aId = a.id
                    adminToDelete = null
                    if (aId != null) {
                        scope.launch {
                            repository.deleteUser(aId, currentUser)
                            onAdminDeleted()
                        }
                    }
                }) { Text("Delete", color = MitraError, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { AppSoundManager.playClick(); adminToDelete = null }) { Text("Cancel") } }
        )
    }

    if (adminToEdit != null && currentUser.isSuperAdminUser) {
        val a = adminToEdit!!
        var eName by remember(a) { mutableStateOf(a.name ?: "") }
        var eMobile by remember(a) { mutableStateOf(a.mobileNumber) }
        var ePassword by remember(a) { mutableStateOf(a.password ?: "") }
        var eErr by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isSaving) adminToEdit = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Text(
                    text = "Edit Admin Details",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MitraNavyPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = eName,
                        onValueChange = { eName = it; eErr = null },
                        label = { Text("Admin Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )
                    OutlinedTextField(
                        value = eMobile,
                        onValueChange = {
                            if (it.length <= 10 && it.all { c -> c.isDigit() }) {
                                eMobile = it
                                eErr = null
                            }
                        },
                        label = { Text("Mobile Number (10 digits)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )
                    OutlinedTextField(
                        value = ePassword,
                        onValueChange = { ePassword = it; eErr = null },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )
                    if (eErr != null) {
                        Text(eErr!!, color = MitraError, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Changes",
                    onClick = { AppSoundManager.playClick();
                        if (eName.isBlank()) {
                            eErr = "Name is required"
                            return@MitraPrimaryButton
                        }
                        if (eMobile.length != 10) {
                            eErr = "Enter valid 10-digit mobile"
                            return@MitraPrimaryButton
                        }
                        if (ePassword.isBlank()) {
                            eErr = "Password cannot be empty"
                            return@MitraPrimaryButton
                        }
                        isSaving = true
                        eErr = null
                        scope.launch {
                            val res = repository.updateUser(
                                userId = a.id ?: 0L,
                                name = eName.trim(),
                                password = ePassword.trim(),
                                callerUser = currentUser,
                                mobileNumber = eMobile.trim()
                            )
                            isSaving = false
                            if (res is Resource.Success) {
                                adminToEdit = null
                                onAdminUpdated()
                            } else if (res is Resource.Error) {
                                eErr = res.message
                            }
                        }
                    },
                    isLoading = isSaving
                )
            },
            dismissButton = {
                TextButton(onClick = { AppSoundManager.playClick(); if (!isSaving) adminToEdit = null }) {
                    Text("Cancel", color = MitraTextSecondary)
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminCreateContentSection(
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    onTestCreated: () -> Unit,
    onQuestionAdded: (Long) -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) }
    var selectedTestId by remember { mutableStateOf<Long?>(testsList.firstOrNull()?.id) }

    LaunchedEffect(testsList) {
        if (selectedTestId == null && testsList.isNotEmpty()) {
            selectedTestId = testsList.first().id
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Surface(shape = RoundedCornerShape(12.dp), color = MitraBgLight, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(4.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (subTab == 0) Color.White else Color.Transparent,
                    modifier = Modifier.weight(1f).clickable { subTab = 0 }
                ) {
                    Box(modifier = Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        Text("1. New Test", fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Normal, color = MitraNavyPrimary, fontSize = 13.sp)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (subTab == 1) Color.White else Color.Transparent,
                    modifier = Modifier.weight(1f).clickable { subTab = 1 }
                ) {
                    Box(modifier = Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        Text("2. Add Question", fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Normal, color = MitraNavyPrimary, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (subTab == 0) {
            val context = LocalContext.current
            var tName by remember { mutableStateOf("") }
            var tDuration by remember { mutableStateOf("15") }
            var tTestDate by remember { mutableStateOf("") }
            var tTestDay by remember { mutableStateOf("") }
            var tDayDropdownExpanded by remember { mutableStateOf(false) }
            var isSaving by remember { mutableStateOf(false) }
            var err by remember { mutableStateOf<String?>(null) }
            val scope = rememberCoroutineScope()
            val nextTestNumber = testsList.size + 1
            val daysList = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MitraNavyPrimary,
                            modifier = Modifier.padding(end = 10.dp)
                        ) {
                            Text(
                                text = "Test $nextTestNumber",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Column {
                            Text("Create New MCQ Test", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MitraNavyPrimary)
                            Text("Next Test Sequence: Test $nextTestNumber", fontSize = 12.sp, color = MitraTextSecondary)
                        }
                    }
                    OutlinedTextField(
                        value = tName,
                        onValueChange = { tName = it; err = null },
                        label = { Text("Test Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = tDuration,
                        onValueChange = { tDuration = it.filter { c -> c.isDigit() }; err = null },
                        label = { Text("Duration (Minutes)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Manual Test Date Picker Field
                    OutlinedTextField(
                        value = tTestDate,
                        onValueChange = { tTestDate = it; err = null },
                        label = { Text("Test Date (DD/MM/YYYY)") },
                        placeholder = { Text("e.g. 20/01/2025") },
                        trailingIcon = {
                            IconButton(onClick = { AppSoundManager.playClick();
                                val cal = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        tTestDate = String.format(Locale.US, "%02d/%02d/%04d", d, m + 1, y)
                                        err = null
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = "Select Date",
                                    tint = MitraNavyPrimary
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Manual Test Day Selection Field (Independent of Date)
                    ExposedDropdownMenuBox(
                        expanded = tDayDropdownExpanded,
                        onExpandedChange = { tDayDropdownExpanded = !tDayDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = tTestDay,
                            onValueChange = { tTestDay = it; err = null },
                            label = { Text("Test Day (e.g. Sunday)") },
                            placeholder = { Text("Select or type Day") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = tDayDropdownExpanded) },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = tDayDropdownExpanded,
                            onDismissRequest = { tDayDropdownExpanded = false }
                        ) {
                            daysList.forEach { day ->
                                DropdownMenuItem(
                                    text = { Text(day) },
                                    onClick = { AppSoundManager.playClick();
                                        tTestDay = day
                                        tDayDropdownExpanded = false
                                        err = null
                                    }
                                )
                            }
                        }
                    }

                    if (err != null) Text(err!!, color = MitraError, fontSize = 12.sp)

                    MitraPrimaryButton(
                        text = "Save Test & Continue",
                        onClick = { AppSoundManager.playClick();
                            val name = tName.trim()
                            val dur = tDuration.toIntOrNull() ?: 0
                            if (name.isBlank() || dur <= 0) {
                                err = "Please enter valid test name and duration"
                                return@MitraPrimaryButton
                            }
                            val cleanDate = tTestDate.trim().ifBlank { null }
                            val cleanDay = tTestDay.trim().ifBlank { null }
                            isSaving = true
                            scope.launch {
                                val res = repository.createTest(name, dur, cleanDate, cleanDay)
                                isSaving = false
                                if (res is Resource.Success) {
                                    tName = ""
                                    tDuration = "15"
                                    tTestDate = ""
                                    tTestDay = ""
                                    onTestCreated()
                                    subTab = 1
                                } else if (res is Resource.Error) {
                                    err = res.message
                                }
                            }
                        },
                        isLoading = isSaving,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        } else {
            val context = LocalContext.current
            var isDropdownExpanded by remember { mutableStateOf(false) }
            var passageText by remember { mutableStateOf("") }
            var qText by remember { mutableStateOf("") }
            var optA by remember { mutableStateOf("") }
            var optB by remember { mutableStateOf("") }
            var optC by remember { mutableStateOf("") }
            var optD by remember { mutableStateOf("") }
            var correctOpt by remember { mutableStateOf("A") }
            var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
            var isSaving by remember { mutableStateOf(false) }
            var msg by remember { mutableStateOf<String?>(null) }
            val scope = rememberCoroutineScope()

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Add Question to Test", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MitraNavyPrimary)

                    val currTest = testsList.firstOrNull { it.id == selectedTestId }
                    val currSeq = currTest?.let { getTestSequenceNumber(it.id ?: 0L, testsList) } ?: 1

                    // Test Selection Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isDropdownExpanded,
                        onExpandedChange = { isDropdownExpanded = !isDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = currTest?.let { "Test $currSeq: ${it.testName}" } ?: "Select Test",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Test") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownExpanded) },
                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable, true).fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = isDropdownExpanded, onDismissRequest = { isDropdownExpanded = false }) {
                            testsList.forEach { t ->
                                val seq = getTestSequenceNumber(t.id ?: 0L, testsList)
                                val isSelected = t.id == selectedTestId
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isSelected) MitraGreen else MitraNavyPrimary,
                                                modifier = Modifier.padding(end = 10.dp)
                                            ) {
                                                Text(
                                                    text = "Test $seq",
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = t.testName,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    color = if (isSelected) MitraNavyPrimary else MitraTextPrimary
                                                )
                                                Text(
                                                    text = "${t.duration} min",
                                                    fontSize = 11.sp,
                                                    color = MitraTextMuted
                                                )
                                            }
                                        }
                                    },
                                    onClick = { AppSoundManager.playClick(); selectedTestId = t.id; isDropdownExpanded = false }
                                )
                            }
                        }
                    }

                    // Optional Paragraph/Poem Field
                    OutlinedTextField(
                        value = passageText,
                        onValueChange = { passageText = it; msg = null },
                        label = { Text("Paragraph/Poem (Optional)") },
                        placeholder = { Text("Enter reading comprehension paragraph/poem for this question...") },
                        minLines = 2,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth().testTag("add_passage_input")
                    )

                    OutlinedTextField(
                        value = qText,
                        onValueChange = { qText = it; msg = null },
                        label = { Text("Question Text") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("add_question_input")
                    )

                    // Optional Question Image Picker
                    QuestionImagePicker(
                        selectedUri = selectedImageUri,
                        existingUrl = null,
                        onImageSelected = { selectedImageUri = it; msg = null },
                        onRemoveImage = { selectedImageUri = null }
                    )

                    OutlinedTextField(value = optA, onValueChange = { optA = it; msg = null }, label = { Text("Option A") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optB, onValueChange = { optB = it; msg = null }, label = { Text("Option B") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optC, onValueChange = { optC = it; msg = null }, label = { Text("Option C") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optD, onValueChange = { optD = it; msg = null }, label = { Text("Option D") }, modifier = Modifier.fillMaxWidth())

                    Text("Correct Answer:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("A", "B", "C", "D").forEach { opt ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(selected = correctOpt == opt, onClick = { AppSoundManager.playClick(); correctOpt = opt })
                                Text(opt, fontWeight = if (correctOpt == opt) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }

                    if (msg != null) Text(msg!!, fontSize = 12.sp, color = MitraNavyPrimary)

                    MitraPrimaryButton(
                        text = "Save Question",
                        onClick = { AppSoundManager.playClick();
                            val tId = selectedTestId ?: 0L
                            if (tId <= 0 || qText.isBlank() || optA.isBlank() || optB.isBlank() || optC.isBlank() || optD.isBlank()) {
                                msg = "All fields are required"
                                return@MitraPrimaryButton
                            }
                            isSaving = true
                            msg = null
                            scope.launch {
                                var uploadedImageUrl: String? = null
                                if (selectedImageUri != null) {
                                    val uploadRes = repository.uploadQuestionImage(selectedImageUri!!, context)
                                    if (uploadRes.isSuccess) {
                                        uploadedImageUrl = uploadRes.getOrNull()
                                    } else {
                                        isSaving = false
                                        msg = "Image upload failed: ${uploadRes.exceptionOrNull()?.localizedMessage ?: "Unknown error"}"
                                        return@launch
                                    }
                                }

                                val cleanPassage = passageText.trim().ifBlank { null }
                                val res = repository.addQuestion(
                                    testId = tId,
                                    questionText = qText.trim(),
                                    optionA = optA.trim(),
                                    optionB = optB.trim(),
                                    optionC = optC.trim(),
                                    optionD = optD.trim(),
                                    correctOption = correctOpt,
                                    imageUrl = uploadedImageUrl,
                                    passageText = cleanPassage
                                )
                                isSaving = false
                                if (res is Resource.Success) {
                                    msg = "Question saved successfully!"
                                    passageText = ""
                                    qText = ""
                                    optA = ""
                                    optB = ""
                                    optC = ""
                                    optD = ""
                                    correctOpt = "A"
                                    selectedImageUri = null
                                    onQuestionAdded(tId)
                                } else if (res is Resource.Error) {
                                    msg = res.message
                                    if (!uploadedImageUrl.isNullOrBlank()) {
                                        val cleanupRes = repository.deleteQuestionImage(uploadedImageUrl)
                                        if (cleanupRes.isFailure) {
                                            android.util.Log.w("AdminHomeScreen", "Failed to cleanup uploaded image after question save failure: ${cleanupRes.exceptionOrNull()?.localizedMessage}")
                                        }
                                    }
                                }
                            }
                        },
                        isLoading = isSaving,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
